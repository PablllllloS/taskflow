import Sidebar from "../componentes/sidebar";

function Sobre(){
    return(     
        <div>
            <Sidebar/>
            <h1>Sobre</h1>
        </div>
    )
}
export default Sobre;