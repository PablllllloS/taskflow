import Header from "../componentes/Header";
import Contador from "../componentes/Contador";
import ListaTarefas from "../componentes/ListaTarefas"; // reutilizado nas colunas
import Sidebar from "../componentes/sidebar";
import ModalTarefa from '../componentes/ModalTarefa'
import { useState, useEffect } from "react";
// import axios from "axios";   ALTERAÇAO PARA O DO MODAL TAREFA

function Kanban() {
  const [proximaId, setProximaId] = useState(1);
  // Estado das tarefas — inicializador de função carrega do localStorage
  const [tarefas, setTarefas] = useState(() => {
    const tarefasSalvas = localStorage.getItem("tarefas");
    if (!tarefasSalvas) return [];
    const tarefasConvertidas = JSON.parse(tarefasSalvas);
    setProximaId(
      tarefasConvertidas[tarefasConvertidas.length - 1]?.id + 1 || 1,
    );
    return Array.isArray(tarefasConvertidas) ? tarefasConvertidas : [];
  });


  const[modalAberto, setModalAberto] = useState(false)
  const[tarefaEditando, setTarefaEditando] = useState(null)
  const[colunaAtiva, setColunaAtiva] = useState('afazer')

  function abrirModalCriar(coluna){
    setTarefaEditando(null);
    setColunaAtiva(coluna);
    setModalAberto(true);
  }

  function abrirModalEditar(tarefa) {
  setTarefaEditando(tarefa); // objeto = modo edição
  setModalAberto(true);
}


  function salvarTarefa(dados){
    if(dados.id){
      setTarefas(tarefas.map(t =>
        t.id === dados.id ? {...t,...dados} : t
      ));
    } else {
      setTarefas([...tarefas, {...dados, id:Date.now() }])  //ALTERAR ESTE DATE.NOW
    }
  }

              //ALTERAÇÃO APRA O DO MODAL TAREFA
  // const [texto, setTexto] = useState("");
  // const [prioridade, setPrioridade] = useState("media");
  // const [cep, setCep] = useState("");

  useEffect(() => {
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
  }, [tarefas]);

            // ALTERAÇÃO PARA O DO MODAL TAREFA

  // const consultarCidade = async (cep) => {
  //   if (cep.trim() === "") return;
  //   try {
  //     const resposta = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
  //     if (resposta.data.erro) {
  //       alert("CEP não encontrado.");
  //       return;
  //     }
  //     return resposta.data.localidade
  //       ? resposta.data.localidade + "/" + resposta.data.uf : "-";
  //   } catch (erro) {
  //     alert("Erro ao consultar CEP: " + erro.message);
  //   }
  // };



  const adicionarTarefa = async () => {
    if (ModalTarefa.texto.trim() === "") return;
    if (ModalTarefa.cep.trim() === "") return;

    const cidade = await consultarCidade(cep);

    const novaTarefa = {
      id: proximaId,
      texto: texto,
      cidade: cidade,
      concluida: false,
      prioridade: prioridade,
      coluna: "afazer",
    };

    setTarefas([...tarefas, novaTarefa]);
    setProximaId(proximaId + 1);
    ModalTarefa.setTexto("");
    ModalTarefa.setPrioridade("media");
  };

  
  const deletarTarefa = (id) => {
    setTarefas(tarefas.filter((tarefa) => tarefa.id !== id));
  };

  
  const alternarConcluida = (id) => {
    setTarefas(
      tarefas.map((tarefa) =>
        tarefa.id === id ? { ...tarefa, concluida: !tarefa.concluida } : tarefa,
      ),
    );
  };

  
  const moverTarefa = (id, novaColuna) => {
    setTarefas(
      tarefas.map((tarefa) =>
        tarefa.id === id
          ? { ...tarefa, coluna: novaColuna } // spread copia tudo, só coluna muda
          : tarefa,
      ),
    );
  };

  
  return (
    <>
      <Sidebar/>
      <Contador />
      <Header
        titulo="TaskFlow - Teste"
        subtitulo="Gerencie suas tarefas"
        tarefas={tarefas}
      />
      <main className="container">
        {/* 

            TUDO ALTERADO PARA O MODAL TAREFA

        <section id="formulario">
          <div className="campo-linha">
            <input
              id="input-tarefa"
              className="input-tarefa"
              type="text"
              placeholder="Nova tarefa..."
              required
              autoComplete="off"
              value={ModalTarefa.texto}
              onChange={(e) => ModalTarefa.setTexto(e.target.value)}
            />
            <input
              id="input-cep"
              className="input-tarefa"
              type="text"
              placeholder="Informe o CEP..."
              required
              autoComplete="off"
              value={ModalTarefa.cep}
              onChange={(e) => ModalTarefa.setCep(e.target.value)}
            />

            <select
              id="sel-prioridade"
              value={prioridade}
              onChange={(e) => setPrioridade(e.target.value)}
            >
              <option value="alta">🔴 Alta</option>
              <option value="media">🟡 Média</option>
              <option value="baixa">🟢 Baixa</option>
            </select>
            <button id="btn-adicionar" type="button" onClick={adicionarTarefa}>
              Adicionar
            </button>
          </div>
        </section> */}

        <div className="kanban-quadro">
          
          <div className="kanban-coluna">
            <div className="kanban-coluna-header">
              <h3>A Fazer</h3>
              <div style={{display: 'flex', gap:'8px', alignItems:'center'}}>
                <span className="kanban-contador">
                  {tarefas.filter((t) => t.coluna === "afazer").length}
                </span>
                <button className="kanban-btn-add" onClick={()=> abrirModalCriar('afazer')}>
                  +
                </button>
              </div>
            </div>

            <ListaTarefas
              tarefas={tarefas.filter((t) => t.coluna === "afazer")}
              onDeletar={deletarTarefa}
              onEditar={abrirModalEditar}
              onMover={moverTarefa}
              colunaAnterior={null}
              colunaProxima="andamento"
            />
          </div>
          <div className="kanban-coluna">
            <div className="kanban-coluna-header">
              <h3>Em Andamento</h3>
              {/* <span className="kanban-contador">
                {tarefas.filter((t) => t.coluna === "andamento").length}
              </span> */}
              <div style={{display: 'flex', gap:'8px', alignItems:'center'}}>
                <span className="kanban-contador">
                  {tarefas.filter((t) => t.coluna === "andamento").length}
                </span>
                <button className="kanban-btn-add" onClick={()=> abrirModalCriar('andamento')}>
                  +
                </button>
              </div>
            </div>
            <ListaTarefas
              tarefas={tarefas.filter((t) => t.coluna === "andamento")}
              onDeletar={deletarTarefa}
              onEditar={abrirModalCriar}
              onMover={moverTarefa}
              colunaAnterior="afazer"
              colunaProxima="concluido"
            />
          </div>

          <div className="kanban-coluna">
            <div className="kanban-coluna-header">
              <h3>Concluído</h3>
              {/* <span className="kanban-contador">
                {tarefas.filter((t) => t.coluna === "concluido").length}
              </span> */}
              <div style={{display: 'flex', gap:'8px', alignItems:'center'}}>
                <span className="kanban-contador">
                  {tarefas.filter((t) => t.coluna === "concluido").length}
                </span>
                <button className="kanban-btn-add" onClick={()=> abrirModalCriar('concluido')}>
                  +
                </button>
              </div>
            </div>
            <ListaTarefas
              tarefas={tarefas.filter((t) => t.coluna === "concluido")}
              onDeletar={deletarTarefa}
              onEditar={abrirModalCriar}
              onMover={moverTarefa}
              colunaAnterior="andamento"
              colunaProxima={null}
            />
          </div>
          <ModalTarefa
            aberto={modalAberto}
            onFechar={()=> setModalAberto(false)}
            onSalvar={salvarTarefa}
            tarefa={tarefaEditando}
            coluna={colunaAtiva}
          />
        </div>
        
       </main>
      <footer>
        <p>
          TaskFlow &copy; 2026 &mdash; Prof. Alan Glei &mdash; SENAI CTGAS-ER
        </p>
      </footer>
    </>
  );
}

export default Kanban;
